<?php
// include './config/db.php';


    include("./template/header.php");
    include("./template/footer.php");




?>