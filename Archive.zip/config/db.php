<?php
// mysql
//  $database = "suwasahana";
$db_name = "suwasahana";
$uname = "nirmal";
$passwd = "root";
$hostname = "localhost";


//  $conn = mysqli_connect($hostname, $uname, $passwd, $db_name);
//  if($conn){
//      echo "Connected to database";
//  }
//  else{   echo "Connection failed"; } 
?>